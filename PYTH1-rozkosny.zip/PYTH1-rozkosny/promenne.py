mesta = ['praha','brno','ostrava']
nalez = 0

def prochazej_mesta():
    # global mesta
    # mesta = ['plzen','olomouc','ostrava']
    for i in mesta:
        if i == 'brno':
            global nalez
            nalez = 1
            if nalez >0:
                nalez = 'ano'
            else:
                nalez = 'ne'
            break

#prochazej_mesta()
print(nalez)
print(mesta)

