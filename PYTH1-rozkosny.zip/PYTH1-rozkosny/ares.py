import pandas as pd

# cesta json souboru
cesta = r'C:\Users\petrrozkosny\OneDrive - CC Marketing Group\Plocha\PYTH1\PYTH1\ares.json'
# vytvoreni pandas dataframe
df = pd.read_json(cesta)
# vyber prvniho radku ze sloupce zaznamy, zde se nachazi slovnik, ze ktereho vybirame klic [ezp]
# ziskany objekt je ale opet slovnik, ze ktereho ziskavame klic [subjektEzp]    
zaznamy  = df['zaznamy'][0]['ezp']['subjektEzp']

# Vytvorte prazdny list datumy_zaniku
datumy_zaniku = []
# Zkuste uzivateli vypsat klic ico
try:
    ico = zaznamy['ico']
    print('ico nalezeno')
# Pokud klic ico ve slovniku je, vypiste uzivateli "ico nalezeno", hodnotu si ulozte do promenne ico
# Pokud klic ico ve slovniku neni, vypiste uzivateli "ico nenalezeno"
except:
    print('ico nenalezeno')

pepa =[1]
'''
Prochazejte slovnikem zaznamy, zde mame nasledujici ukoly
1. Pokud se nam podari najit klic datumZaniku, tak tuto hodnotu pridejme do listu
2. Pokud se nam nepodari ani v jedne z iteraci najit datumZaniku, tj. list datumy_zaniku je prazdny, vypiste uzivateli "datum zaniku nenalezen"
'''


for k,v in zaznamy.items():
    if k == 'datumZaniku':
        datumy_zaniku.append(v)
if len(datumy_zaniku) == 0:
    # alternativne jde if not datum_zaniku
    print('datum zaniku nenalezen')

for k,v in zaznamy.items():
    if type(v)==dict:
        for k1,v1 in v.items():
            print(k1,v1)
    elif type(v) == list:
        for i in v:
            print(i)
    else:
        print(v)
# Pokud je hodnota typu dictionary, tj. type(v) == dict, prochazejte timto vnorenym slovnikem a vypisujte jeho klice a hodnoty

# Pokud je hodnota typu list, tj. type(v) == list, prochazejte timto vnorenym listem a vypisujte jeho hodnoty

# Pokud neni splneno ani jedno z vyse uvedenych, vypiste hodnotu


def zkontroluj_kraj(kraj):
    if zaznamy['sidlo']['kodKraje'] == kraj:
        return 'kraj nalezen'
    else:
        return 'kraj nenalezen'

kontrolovany_kraj = input('Zadejte kraj: ')
try:
    kontrolovany_kraj = int(kontrolovany_kraj)
    i = zkontroluj_kraj(kontrolovany_kraj)
    print(i)
except ValueError:
    print('Neplatny vstup')

# Vytvorte funkci zkontroluj_kraj, ktera bude mit jeden pozicni parametr kraj
# Funkce vrati uzivateli hodnotu:
# - kraj nalezen, pokud hodnota klice kodKraje odpovida uzivatelem zadane hodnote
# - kraj nenalezen, pokud hodnota klice kodKraje neodpovida uzivatelem zadane hodnote
# vytvorte promennou kontrolovany_kraj, do ktere ulozite vstup uzivatele
# Pokud se vstup uzivatele podari prevest na cislo, zavolejte funkci zkontroluj_kraj s na cislo prevedenou hodnotou a vypiste vysledek
# Pokud se vstup uzivatele nepodari prevest na cislo, vypiste uzivateli "Neplatny vstup"

