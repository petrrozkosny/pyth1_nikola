import copy

mesto = [['Praha']]
mesto2 = copy.deepcopy(mesto)
mesto2.append('Brno')
print(f'mesto1 :{mesto}')
print(f'mesto2: {mesto2}')