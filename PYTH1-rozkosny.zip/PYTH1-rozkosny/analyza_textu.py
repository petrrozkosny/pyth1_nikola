from fuzzywuzzy import fuzz

ico = 45274649

shody = {}
firma = 'mountfield'
firma2 = 'mauntfielt'
firma3 = 'alza'

jmeno = 'petr rozkošný'
jmeno2 = 'rozkošný petr'

slova = ['mountfield','mauntfielt','alza']

for i in slova:
    for ii in slova:
        if fuzz.ratio(i,ii) >=80:
            shody.update({i:ii})

print(fuzz.token_sort_ratio(jmeno,jmeno2))

# ------------------------------
import re
import requests
from bs4 import BeautifulSoup
url_adresa = 'https://www.ictpro.cz/kontakty.aspx'

# zavolej url adresu
stranka = requests.get(url_adresa)
# ziskej text z url adresy, parsuj html
soup = BeautifulSoup(stranka.text, 'html.parser')
hodnoty =re.findall(r'\D([\d]{8})\D',soup.text)
print(hodnoty)
#najdi ico

for i in hodnoty:
    i = int(i)
    if i % 11 == 0:
        print(i)
        break