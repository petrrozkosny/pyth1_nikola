

regulary = {'czc':r'{w}'}


url = {'czc': [
'https://www.czc.cz/tcl-65c735-164cm/342494a/produkt',
'https://www.czc.cz/lego-minecraft-21246-bitva-v-deep-darku/363112a/produkt',
'https://www.czc.cz/marshall-major-iv-bluetooth-cerna/311135a/produkt']}

regulary[k]