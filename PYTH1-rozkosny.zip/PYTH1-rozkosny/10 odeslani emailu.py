# Zdroj https://realpython.com/python-send-email/

import smtplib

#Knihovny potrebne pro odeslani e-mailu s formatovanym textem
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
odesilatel = 'odesilatel@gmail.com'
prijemce = 'prijemce@gmail.com'
heslo = ''

# HTML tělo e-mailu
text_zpravy = """
<html>
  <head></head>
  <body>
    <p>Toto je <b>testovací zpráva</b> odeslaná z Pythonu.</p>
  </body>
</html>
"""


# Vytvoreni instance MIMEMultipart objektu
msg = MIMEMultipart()
# hodnota pro odesilatele
msg['From'] = odesilatel
# hodnota pro prijemce zpravy
msg['To'] = prijemce
# predmet zpravy
msg['Subject'] = 'pozor, pozor'
# text zpravy
msg.attach(MIMEText(text_zpravy, 'html'))

# prihlaseni k postovnimu serveru
server = smtplib.SMTP('smtp.office365.com', 587) 
server.starttls() # Aktivace TLS pro zabezpečení
#prihlaseni se k postovnimu serveru
server.login(odesilatel, heslo)
# prevedeni pole zpravy do stringu
text = msg.as_string()
# odeslani zpravy
server.sendmail(odesilatel, prijemce, text)
# ukonceni spojeni s postovnim serverem
server.quit()