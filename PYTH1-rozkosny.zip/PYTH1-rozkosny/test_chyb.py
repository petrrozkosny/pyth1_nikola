from test import pozdrav_python
jazyk = 'Python'


def pozdrav_python():
    print(jazyk)
pozdrav_python()