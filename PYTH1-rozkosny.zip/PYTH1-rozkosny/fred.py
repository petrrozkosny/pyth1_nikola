import requests
from bs4 import BeautifulSoup

url = 'https://fred.stlouisfed.org/series/CORESTICKM159SFRBATL'
stranka = requests.get(url)
soup = BeautifulSoup(stranka.text, 'html.parser')
print(soup)
